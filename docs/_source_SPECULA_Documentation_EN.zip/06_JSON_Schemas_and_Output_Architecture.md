# SPECULA AI – JSON SCHEMAS AND OUTPUT ARCHITECTURE
(English version)

See canvas document: Specula Ai – Json Schemas And Output Architecture (english)
