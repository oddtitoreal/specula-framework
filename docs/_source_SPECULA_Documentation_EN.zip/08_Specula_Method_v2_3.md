# SPECULA METHOD v2.3
(English version)

See canvas document: Specula Method V2
