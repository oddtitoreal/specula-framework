# FOUNDATIONS OF THE SPECULA METHOD
(English version)

See canvas document: Specula – Foundations Of The Method (english)
