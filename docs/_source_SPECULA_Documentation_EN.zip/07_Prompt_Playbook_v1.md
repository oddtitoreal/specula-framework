# SPECULA PROMPT PLAYBOOK v1.0
(English version)

See canvas document: Specula Prompt Playbook V1
