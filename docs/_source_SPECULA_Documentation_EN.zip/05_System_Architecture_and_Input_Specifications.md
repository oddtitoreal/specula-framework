# SPECULA AI – SYSTEM ARCHITECTURE AND INPUT SPECIFICATIONS
(English version)

See canvas document: Specula Ai – System Architecture And Input Specifications (english)
