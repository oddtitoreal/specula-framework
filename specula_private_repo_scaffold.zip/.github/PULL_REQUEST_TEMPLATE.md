## What changed?

## Why?

## Checklist
- [ ] Updated CHANGELOG.md (if applicable)
- [ ] Terminology consistent with specs/terminology.md
- [ ] No precedence conflicts introduced
