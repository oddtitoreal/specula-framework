---
name: Feature request
about: Suggest an addition to the repo (templates, schemas, prompts)
title: "[request] "
labels: enhancement
---

## Request

## Why

## Scope
docs/specs/schemas/prompts/templates
