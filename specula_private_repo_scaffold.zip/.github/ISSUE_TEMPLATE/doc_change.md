---
name: Document change
about: Propose a change to SPECULA documentation
title: "[docs] "
labels: documentation
---

## Document
Which file(s)?

## Proposed change
What and why?

## Impact
Does it affect precedence, behavior, or schemas?
