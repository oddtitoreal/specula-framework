---
name: Bug report
about: Report an issue in the documentation or templates
title: "[bug] "
labels: bug
---

## What happened?

## Where?
File path(s)

## Expected
