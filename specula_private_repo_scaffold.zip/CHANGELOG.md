# Changelog

All notable changes to this repository are documented here.

## Unreleased
- Initial private delivery scaffold.

## 2026-01-24
- Repository structure created.
- Imported English documentation set into `docs/`.
