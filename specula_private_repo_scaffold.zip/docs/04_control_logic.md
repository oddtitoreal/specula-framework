# SPECULA AI – CONTROL LOGIC AND STATE MACHINE
(English version)

See canvas document: Specula Ai – Control Logic And State Machine
