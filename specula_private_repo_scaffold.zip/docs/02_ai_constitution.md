# SPECULA AI CONSTITUTION
(English version)

See canvas document: Specula Ai – Constitution (english)
