# SPECULA AI – TECHNICAL TRANSLATION AND OPERATIONAL GOVERNANCE
(English version)

See canvas document: Specula Ai – Technical Translation And Operational Governance (english)
